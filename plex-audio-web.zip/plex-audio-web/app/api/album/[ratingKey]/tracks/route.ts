import { NextResponse } from "next/server";
import { plexFetch, toArray } from "@/lib/plex";
import { normalizeTrack } from "@/lib/normalize";

export const runtime = "nodejs";

export async function GET(_: Request, context: { params: Promise<{ ratingKey: string }> }) {
  try {
    const { ratingKey } = await context.params;
    const data = await plexFetch(`/library/metadata/${ratingKey}/children`);
    const items = toArray((data as any)?.MediaContainer?.Metadata);

    const parent = items[0]
      ? {
          album: items[0].parentTitle || "",
          artist: items[0].grandparentTitle || "",
          year: items[0].year || null,
          thumb: items[0].thumb || items[0].parentThumb || items[0].grandparentThumb || ""
        }
      : undefined;

    return NextResponse.json(items.map((item: any) => normalizeTrack(item, parent)));
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}
