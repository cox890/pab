import { plexHeaders } from "@/lib/plex";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const key = searchParams.get("key") || "";
  if (!key) {
    return new Response("Missing key", { status: 400 });
  }

  const base = (process.env.PLEX_BASE_URL || "").replace(/\/$/, "");
  const range = request.headers.get("range");

  const response = await fetch(`${base}${key}`, {
    headers: plexHeaders(range ? { Range: range } : {}) as HeadersInit,
    cache: "no-store"
  });

  if (!response.ok && response.status !== 206) {
    return new Response(await response.text(), { status: response.status });
  }

  const headers = new Headers();
  ["content-type", "content-length", "content-range", "accept-ranges", "etag", "last-modified"].forEach((header) => {
    const value = response.headers.get(header);
    if (value) headers.set(header, value);
  });
  headers.set("Cache-Control", "no-store");

  return new Response(response.body, {
    status: response.status,
    headers
  });
}
