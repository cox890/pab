import { NextResponse } from "next/server";
import { plexFetch, toArray } from "@/lib/plex";
import { normalizeBook } from "@/lib/normalize";

export const runtime = "nodejs";

export async function GET(_: Request, context: { params: Promise<{ ratingKey: string }> }) {
  try {
    const { ratingKey } = await context.params;
    const data = await plexFetch(`/library/metadata/${ratingKey}`);
    const item = toArray((data as any)?.MediaContainer?.Metadata)[0];
    if (!item) {
      return NextResponse.json({ error: "Book not found" }, { status: 404 });
    }
    return NextResponse.json(normalizeBook(item));
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}
