import { NextResponse } from "next/server";
import { plexFetch } from "@/lib/plex";

export const runtime = "nodejs";

export async function GET() {
  try {
    const data = await plexFetch("/");
    return NextResponse.json({ ok: true, data });
  } catch (error) {
    return NextResponse.json({ ok: false, error: (error as Error).message }, { status: 500 });
  }
}
