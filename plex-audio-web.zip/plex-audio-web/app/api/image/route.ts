import { plexHeaders } from "@/lib/plex";

export const runtime = "nodejs";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const path = searchParams.get("path") || "";

  if (!path) {
    return new Response("Missing path", { status: 400 });
  }

  const base = (process.env.PLEX_BASE_URL || "").replace(/\/$/, "");
  const response = await fetch(`${base}${path}`, {
    headers: plexHeaders()
  });

  if (!response.ok) {
    return new Response("Failed to load image", { status: response.status });
  }

  return new Response(response.body, {
    status: 200,
    headers: {
      "Content-Type": response.headers.get("content-type") || "image/jpeg",
      "Cache-Control": "public, s-maxage=86400, stale-while-revalidate=604800"
    }
  });
}
