import { NextResponse } from "next/server";
import { getAudioSectionKeys, plexFetch, toArray } from "@/lib/plex";
import { proxiedThumb } from "@/lib/normalize";

export const runtime = "nodejs";

export async function GET() {
  try {
    const data = await plexFetch("/library/sections");
    let sections = toArray((data as any)?.MediaContainer?.Directory).filter(
      (section: any) => section.type === "artist" || section.type === "music"
    );

    const allowed = getAudioSectionKeys();
    if (allowed.length) {
      sections = sections.filter((section: any) => allowed.includes(String(section.key)));
    }

    return NextResponse.json(
      sections.map((section: any) => ({
        key: String(section.key),
        title: section.title,
        type: section.type,
        agent: section.agent,
        thumb: proxiedThumb(section.thumb || section.art || "")
      }))
    );
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}
