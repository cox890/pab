import { NextResponse } from "next/server";
import { plexFetch, toArray } from "@/lib/plex";
import { normalizeAlbum } from "@/lib/normalize";

export const runtime = "nodejs";

export async function GET(_: Request, context: { params: Promise<{ sectionKey: string }> }) {
  try {
    const { sectionKey } = await context.params;
    const data = await plexFetch(`/library/sections/${sectionKey}/all?type=9`);
    const items = toArray((data as any)?.MediaContainer?.Metadata);
    return NextResponse.json(items.map(normalizeAlbum));
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}
