import { NextResponse } from "next/server";
import { plexFetch, toArray } from "@/lib/plex";
import { normalizeAlbum, normalizeBook } from "@/lib/normalize";

export const runtime = "nodejs";

export async function GET(_: Request, context: { params: Promise<{ sectionKey: string }> }) {
  try {
    const { sectionKey } = await context.params;
    const data = await plexFetch(`/library/sections/${sectionKey}/recentlyAdded`);
    const items = toArray((data as any)?.MediaContainer?.Metadata);

    return NextResponse.json(
      items.map((item: any) => (item.type === "album" ? normalizeAlbum(item) : normalizeBook(item)))
    );
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}
