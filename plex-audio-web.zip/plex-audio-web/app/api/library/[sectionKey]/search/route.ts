import { NextResponse } from "next/server";
import { plexFetch, toArray } from "@/lib/plex";
import { normalizeAlbum, normalizeBook, normalizeTrack } from "@/lib/normalize";

export const runtime = "nodejs";

export async function GET(request: Request, context: { params: Promise<{ sectionKey: string }> }) {
  try {
    const { sectionKey } = await context.params;
    const { searchParams } = new URL(request.url);
    const q = (searchParams.get("q") || "").trim();
    if (!q) return NextResponse.json([]);

    const data = await plexFetch(`/library/sections/${sectionKey}/search?query=${encodeURIComponent(q)}`);
    const items = toArray((data as any)?.MediaContainer?.Metadata);

    return NextResponse.json(
      items.map((item: any) => {
        if (item.type === "track") return normalizeTrack(item);
        if (item.type === "album") return normalizeAlbum(item);
        return normalizeBook(item);
      })
    );
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 500 });
  }
}
