import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Plex Audio Web",
  description: "Plexamp-style web player for music and audiobooks"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
