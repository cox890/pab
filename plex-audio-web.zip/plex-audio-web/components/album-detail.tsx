import type { AudioTrack } from "@/lib/types";
import { formatTime } from "@/lib/utils";

export function AlbumDetail({ tracks, onPlayAll, onPlayAt }: { tracks: AudioTrack[]; onPlayAll: () => void; onPlayAt: (index: number) => void; }) {
  const first = tracks[0];

  return (
    <div className="detail">
      <div>
        <img src={first.thumb || ""} alt={first.album || first.title} />
      </div>
      <div>
        <div className="meta">Album</div>
        <h2>{first.album || first.title}</h2>
        <div className="meta">{first.artist || "Unknown artist"}</div>
        <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
          <button className="btn" onClick={onPlayAll}>Play all</button>
        </div>
        <div className="track-list">
          {tracks.map((track, index) => (
            <div className="track-row" key={track.ratingKey}>
              <div>
                <div style={{ fontWeight: 700 }}>{track.title}</div>
                <div className="meta">{track.artist}</div>
              </div>
              <div className="meta">{formatTime((track.duration || 0) / 1000)}</div>
              <button className="btn" onClick={() => onPlayAt(index)}>Play</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
