import type { Book } from "@/lib/types";
import { formatTime } from "@/lib/utils";

export function BookDetail({ book, onPlay, onJumpToChapter }: { book: Book; onPlay: () => void; onJumpToChapter: (index: number) => void; }) {
  return (
    <div className="detail">
      <div>
        <img src={book.thumb || ""} alt={book.title} />
      </div>
      <div>
        <div className="meta">Audiobook</div>
        <h2>{book.title}</h2>
        <div className="meta">{book.author || "Unknown author"}</div>
        <p className="meta" style={{ fontSize: 14, lineHeight: 1.6 }}>{book.summary || "No summary available."}</p>
        <button className="btn" onClick={onPlay}>Play</button>

        <div className="chapter-list">
          {book.chapters.length ? book.chapters.map((chapter, index) => (
            <div className="chapter-row" key={chapter.id}>
              <div>
                <div style={{ fontWeight: 700 }}>{chapter.title}</div>
                <div className="meta">{formatTime(chapter.startTimeOffset / 1000)} – {formatTime(chapter.endTimeOffset / 1000)}</div>
              </div>
              <button className="btn" onClick={() => onJumpToChapter(index)}>Jump</button>
            </div>
          )) : <div className="meta">No embedded chapters found.</div>}
        </div>
      </div>
    </div>
  );
}
