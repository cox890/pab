import { formatTime } from "@/lib/utils";

export function BottomPlayer({ nowPlaying, playing, currentTime, duration, onTogglePlay, onSeek, onSeekBy, onPrev, onNext, playbackRate, onPlaybackRate }: any) {
  const progress = duration > 0 ? currentTime / duration : 0;

  return (
    <div className="bottom-player">
      <div className="bottom-player-grid">
        <div>
          <div style={{ fontWeight: 700 }}>{nowPlaying?.title || "Nothing playing"}</div>
          <div className="meta">{nowPlaying?.artist || nowPlaying?.author || nowPlaying?.album || "Choose an item"}</div>
        </div>

        <div>
          <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 8, flexWrap: "wrap" }}>
            <button className="secondary-btn" onClick={() => onSeekBy(-30)}>-30</button>
            <button className="secondary-btn" onClick={onPrev}>Prev</button>
            <button className="btn" onClick={onTogglePlay}>{playing ? "Pause" : "Play"}</button>
            <button className="secondary-btn" onClick={onNext}>Next</button>
            <button className="secondary-btn" onClick={() => onSeekBy(30)}>+30</button>
          </div>
          <input className="range" type="range" min={0} max={1000} value={progress * 1000} onChange={(e) => onSeek(Number(e.target.value) / 1000)} />
          <div className="meta" style={{ display: "flex", justifyContent: "space-between" }}>
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <select value={playbackRate} onChange={(e) => onPlaybackRate(Number(e.target.value))}>
            <option value={0.8}>0.8x</option>
            <option value={1}>1.0x</option>
            <option value={1.25}>1.25x</option>
            <option value={1.5}>1.5x</option>
            <option value={1.75}>1.75x</option>
            <option value={2}>2.0x</option>
          </select>
        </div>
      </div>
    </div>
  );
}
