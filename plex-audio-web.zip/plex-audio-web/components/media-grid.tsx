export function MediaGrid({ items, onOpenAlbum, onOpenBook, queueMode = false, onPlayItem }: any) {
  if (!items?.length) {
    return <div className="card-body">No items found.</div>;
  }

  return (
    <div className="grid">
      {items.map((item: any, index: number) => {
        const isAlbum = item.type === "album";
        return (
          <div className="card" key={item.ratingKey || `${item.title}-${index}`}>
            <img className="cover" src={item.thumb || ""} alt={item.title} />
            <div className="card-body">
              <div className="title">{item.title}</div>
              <div className="meta">{item.artist || item.author || "Unknown creator"}</div>
              <div className="summary">{item.summary || "Audiobook, album, or long-form audio item"}</div>
              {queueMode ? (
                <button className="btn" onClick={() => onPlayItem?.(index)}>Play</button>
              ) : isAlbum ? (
                <button className="btn" onClick={() => onOpenAlbum(item.ratingKey)}>Open</button>
              ) : (
                <button className="btn" onClick={() => onOpenBook(item.ratingKey)}>Open</button>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
