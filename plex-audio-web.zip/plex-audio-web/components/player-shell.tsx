"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { AudioTrack, Book, Library } from "@/lib/types";
import { Sidebar } from "./sidebar";
import { MediaGrid } from "./media-grid";
import { AlbumDetail } from "./album-detail";
import { BookDetail } from "./book-detail";
import { BottomPlayer } from "./bottom-player";

export function PlayerShell() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [libraries, setLibraries] = useState<Library[]>([]);
  const [activeLibrary, setActiveLibrary] = useState<string>("");
  const [view, setView] = useState<"recent" | "albums" | "queue">("recent");
  const [items, setItems] = useState<any[]>([]);
  const [albumTracks, setAlbumTracks] = useState<AudioTrack[] | null>(null);
  const [book, setBook] = useState<Book | null>(null);
  const [query, setQuery] = useState("");
  const [queue, setQueue] = useState<(AudioTrack | Book)[]>([]);
  const [queueIndex, setQueueIndex] = useState(-1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);

  useEffect(() => {
    fetch("/api/libraries")
      .then((r) => r.json())
      .then((data) => {
        setLibraries(data);
        if (data[0]?.key) setActiveLibrary(data[0].key);
      })
      .catch(console.error);
  }, []);

  useEffect(() => {
    if (!activeLibrary) return;
    void loadRecent(activeLibrary);
  }, [activeLibrary]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTime = () => {
      setCurrentTime(audio.currentTime);
      const item = queue[queueIndex];
      if (item?.ratingKey) {
        localStorage.setItem(`progress:${item.ratingKey}`, String(audio.currentTime));
      }
    };
    const onLoaded = () => setDuration(audio.duration || 0);
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onEnded = () => {
      setQueueIndex((prev) => {
        const next = prev + 1;
        if (next < queue.length) return next;
        return prev;
      });
    };

    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("loadedmetadata", onLoaded);
    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);
    audio.addEventListener("ended", onEnded);

    return () => {
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("loadedmetadata", onLoaded);
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
      audio.removeEventListener("ended", onEnded);
    };
  }, [queue, queueIndex]);

  useEffect(() => {
    const item = queue[queueIndex];
    const audio = audioRef.current;
    if (!item || !audio || !item.streamUrl) return;
    audio.src = item.streamUrl;
    audio.playbackRate = playbackRate;
    const saved = Number(localStorage.getItem(`progress:${item.ratingKey}`) || 0);
    audio.currentTime = saved;
    void audio.play();
  }, [queueIndex, queue, playbackRate]);

  const nowPlaying = useMemo(() => queue[queueIndex] || null, [queue, queueIndex]);

  async function loadRecent(libraryKey = activeLibrary) {
    setView("recent");
    setAlbumTracks(null);
    setBook(null);
    const data = await fetch(`/api/library/${libraryKey}/recent`).then((r) => r.json());
    setItems(data);
  }

  async function loadAlbums() {
    setAlbumTracks(null);
    setBook(null);
    const data = await fetch(`/api/library/${activeLibrary}/albums`).then((r) => r.json());
    setItems(data);
    setView("albums");
  }

  async function search(value: string) {
    setQuery(value);
    if (!value.trim()) {
      await loadRecent();
      return;
    }
    setAlbumTracks(null);
    setBook(null);
    const data = await fetch(`/api/library/${activeLibrary}/search?q=${encodeURIComponent(value)}`).then((r) => r.json());
    setItems(data);
  }

  async function openAlbum(ratingKey: string) {
    const data = await fetch(`/api/album/${ratingKey}/tracks`).then((r) => r.json());
    setAlbumTracks(data);
    setBook(null);
  }

  async function openBook(ratingKey: string) {
    const data = await fetch(`/api/book/${ratingKey}`).then((r) => r.json());
    setBook(data);
    setAlbumTracks(null);
  }

  function playQueue(nextQueue: (AudioTrack | Book)[], startIndex = 0, ignoreSaved = false) {
    if (ignoreSaved) {
      const item = nextQueue[startIndex];
      if (item?.ratingKey) localStorage.removeItem(`progress:${item.ratingKey}`);
    }
    setQueue(nextQueue);
    setQueueIndex(startIndex);
    setView("queue");
  }

  function togglePlay() {
    const audio = audioRef.current;
    if (!audio) return;
    if (audio.paused) void audio.play();
    else audio.pause();
  }

  function seekTo(percent: number) {
    const audio = audioRef.current;
    if (!audio || !audio.duration) return;
    audio.currentTime = audio.duration * percent;
  }

  function seekBy(seconds: number) {
    const audio = audioRef.current;
    if (!audio) return;
    audio.currentTime = Math.max(0, audio.currentTime + seconds);
  }

  return (
    <div className="app-shell">
      <Sidebar
        libraries={libraries}
        activeLibrary={activeLibrary}
        onChangeLibrary={setActiveLibrary}
        view={view}
        onViewRecent={() => { void loadRecent(); }}
        onViewAlbums={() => { void loadAlbums(); }}
        onViewQueue={() => {
          setView("queue");
          setAlbumTracks(null);
          setBook(null);
        }}
      />

      <main className="content-shell">
        <div className="topbar">
          <div>
            <h1>Plex Audio Web</h1>
            <p>Music, audiobooks, and long-form `.m4b` playback in the browser.</p>
          </div>
          <input
            className="search-input"
            placeholder="Search albums, tracks, books, authors..."
            value={query}
            onChange={(e) => void search(e.target.value)}
          />
        </div>

        {view === "queue" && !albumTracks && !book ? (
          queue.length ? (
            <div className="queue-list">
              {queue.map((item, index) => (
                <div className="queue-card" key={item.ratingKey}>
                  <div>
                    <div style={{ fontWeight: 700 }}>{item.title}</div>
                    <div className="meta">{item.artist || item.author || item.album || "Queue item"}</div>
                  </div>
                  <button className="btn" onClick={() => playQueue(queue, index)}>Play</button>
                </div>
              ))}
            </div>
          ) : (
            <div className="card-body">Queue is empty.</div>
          )
        ) : albumTracks ? (
          <AlbumDetail tracks={albumTracks} onPlayAll={() => playQueue(albumTracks, 0)} onPlayAt={(i) => playQueue(albumTracks, i)} />
        ) : book ? (
          <BookDetail
            book={book}
            onPlay={() => playQueue([book], 0, true)}
            onJumpToChapter={(i) => {
              playQueue([book], 0, true);
              window.setTimeout(() => {
                const audio = audioRef.current;
                if (audio) audio.currentTime = (book.chapters[i]?.startTimeOffset || 0) / 1000;
              }, 100);
            }}
          />
        ) : (
          <MediaGrid items={items} onOpenAlbum={openAlbum} onOpenBook={openBook} />
        )}
      </main>

      <BottomPlayer
        nowPlaying={nowPlaying}
        playing={playing}
        currentTime={currentTime}
        duration={duration}
        onTogglePlay={togglePlay}
        onSeek={seekTo}
        onSeekBy={seekBy}
        onPrev={() => setQueueIndex((i) => Math.max(0, i - 1))}
        onNext={() => setQueueIndex((i) => Math.min(queue.length - 1, i + 1))}
        playbackRate={playbackRate}
        onPlaybackRate={(v: number) => {
          setPlaybackRate(v);
          if (audioRef.current) audioRef.current.playbackRate = v;
        }}
      />

      <audio ref={audioRef} preload="metadata" />
    </div>
  );
}
