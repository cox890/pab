import type { Library } from "@/lib/types";

export function Sidebar({
  libraries,
  activeLibrary,
  onChangeLibrary,
  view,
  onViewRecent,
  onViewAlbums,
  onViewQueue
}: {
  libraries: Library[];
  activeLibrary: string;
  onChangeLibrary: (key: string) => void;
  view: "recent" | "albums" | "queue";
  onViewRecent: () => void;
  onViewAlbums: () => void;
  onViewQueue: () => void;
}) {
  return (
    <aside className="sidebar">
      <div className="brand">Plex Audio Web</div>
      <p className="muted">A web player for Plex music and audiobooks.</p>

      <div className="side-label">Libraries</div>
      {libraries.map((lib) => (
        <button
          key={lib.key}
          className={`library-btn ${lib.key === activeLibrary ? "active" : ""}`}
          onClick={() => onChangeLibrary(lib.key)}
        >
          <div style={{ fontWeight: 700 }}>{lib.title}</div>
          <div className="meta">{lib.type}</div>
        </button>
      ))}

      <div className="side-label">Views</div>
      <button className={`nav-btn ${view === "recent" ? "active" : ""}`} onClick={onViewRecent}>Recently added</button>
      <button className={`nav-btn ${view === "albums" ? "active" : ""}`} onClick={onViewAlbums}>Albums / books</button>
      <button className={`nav-btn ${view === "queue" ? "active" : ""}`} onClick={onViewQueue}>Queue</button>
    </aside>
  );
}
