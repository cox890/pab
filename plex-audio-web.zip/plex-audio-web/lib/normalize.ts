import { Album, AudioTrack, Book, Chapter } from "./types";
import { toArray } from "./plex";

export function proxiedThumb(path?: string) {
  if (!path) return "";
  return `/api/image?path=${encodeURIComponent(path)}`;
}

export function streamUrl(partKey?: string | null) {
  if (!partKey) return null;
  return `/api/audio/stream?key=${encodeURIComponent(partKey)}`;
}

export function normalizeTrack(item: any, parent?: Partial<AudioTrack>): AudioTrack {
  const media = toArray(item.Media)[0] || null;
  const part = toArray(media?.Part)[0] || null;

  return {
    ratingKey: item.ratingKey,
    title: item.title,
    album: item.parentTitle || parent?.album || "",
    artist: item.grandparentTitle || parent?.artist || "",
    year: item.year || parent?.year || null,
    duration: item.duration || 0,
    thumb: proxiedThumb(item.thumb || item.parentThumb || item.grandparentThumb || parent?.thumb || ""),
    playable: Boolean(part?.key),
    partKey: part?.key || null,
    streamUrl: streamUrl(part?.key),
    mediaType: item.type,
    index: item.index || null,
    parentIndex: item.parentIndex || null,
    container: media?.container || null,
    audioCodec: media?.audioCodec || null
  };
}

export function normalizeAlbum(item: any): Album {
  return {
    ratingKey: item.ratingKey,
    title: item.title,
    artist: item.parentTitle || item.grandparentTitle || "",
    year: item.year || null,
    summary: item.summary || "",
    thumb: proxiedThumb(item.thumb || item.parentThumb || item.art || ""),
    key: item.key,
    leafCount: item.leafCount || 0,
    type: item.type
  };
}

export function normalizeBook(item: any): Book {
  const media = toArray(item.Media)[0] || null;
  const part = toArray(media?.Part)[0] || null;
  const chapters: Chapter[] = toArray(part?.Chapter).map((c: any, i: number) => ({
    id: c.id || `${item.ratingKey}-${i + 1}`,
    index: c.index || i + 1,
    title: c.tag || `Chapter ${i + 1}`,
    startTimeOffset: Number(c.startTimeOffset || 0),
    endTimeOffset: Number(c.endTimeOffset || item.duration || 0)
  }));

  return {
    ratingKey: item.ratingKey,
    title: item.title,
    author: item.originalTitle || item.parentTitle || item.grandparentTitle || "",
    year: item.year || null,
    summary: item.summary || "",
    thumb: proxiedThumb(item.thumb || item.art || ""),
    duration: item.duration || 0,
    playable: Boolean(part?.key),
    partKey: part?.key || null,
    streamUrl: streamUrl(part?.key),
    type: item.type,
    chapters,
    container: media?.container || null,
    audioCodec: media?.audioCodec || null
  };
}
