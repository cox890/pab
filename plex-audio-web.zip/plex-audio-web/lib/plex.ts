const PLEX_BASE_URL = (process.env.PLEX_BASE_URL || "").replace(/\/$/, "");
const PLEX_TOKEN = process.env.PLEX_TOKEN || "";
const ALLOW_INSECURE = process.env.ALLOW_INSECURE === "true";

if (ALLOW_INSECURE) {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
}

export function getAudioSectionKeys(): string[] {
  return (process.env.AUDIO_SECTION_KEYS || "")
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean);
}

export function plexHeaders(extra: HeadersInit = {}): HeadersInit {
  return {
    Accept: "application/json",
    "X-Plex-Token": PLEX_TOKEN,
    "X-Plex-Client-Identifier": "plex-audio-web-nextjs",
    "X-Plex-Product": "Plex Audio Web",
    "X-Plex-Version": "1.0.0",
    ...extra
  };
}

export async function plexFetch(path: string, init: RequestInit = {}) {
  if (!PLEX_BASE_URL || !PLEX_TOKEN) {
    throw new Error("Missing PLEX_BASE_URL or PLEX_TOKEN.");
  }

  const response = await fetch(`${PLEX_BASE_URL}${path}`, {
    ...init,
    headers: plexHeaders(init.headers || {})
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Plex request failed: ${response.status} ${response.statusText} - ${text}`);
  }

  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return response.json();
  }

  return response.text();
}

export function toArray<T>(value: T | T[] | null | undefined): T[] {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}
