export type Library = {
  key: string;
  title: string;
  type: string;
  agent?: string;
  thumb?: string;
};

export type AudioTrack = {
  ratingKey: string;
  title: string;
  album?: string;
  artist?: string;
  author?: string;
  year?: number | null;
  duration?: number;
  thumb?: string;
  playable: boolean;
  partKey?: string | null;
  streamUrl?: string | null;
  mediaType?: string;
  index?: number | null;
  parentIndex?: number | null;
  container?: string | null;
  audioCodec?: string | null;
};

export type Album = {
  ratingKey: string;
  title: string;
  artist?: string;
  year?: number | null;
  summary?: string;
  thumb?: string;
  key?: string;
  leafCount?: number;
  type: string;
};

export type Chapter = {
  id: string;
  index: number;
  title: string;
  startTimeOffset: number;
  endTimeOffset: number;
};

export type Book = {
  ratingKey: string;
  title: string;
  author?: string;
  year?: number | null;
  summary?: string;
  thumb?: string;
  duration?: number;
  playable: boolean;
  partKey?: string | null;
  streamUrl?: string | null;
  type: string;
  chapters: Chapter[];
  container?: string | null;
  audioCodec?: string | null;
};

export type MediaItem = Album | Book | AudioTrack;
